#include <iostream>
#include <fstream>
#include <string>
#include <limits>
using namespace std;

float convertGradeToPoints(const string& grade)
{
    if (grade.length() != 1) return -1.0;
    char firstChar = grade[0];
    switch (firstChar)
    {
        case 'A':
        case 'a':
            return 4.0;
        case 'B':
        case 'b':
            return 3.0;
        case 'C':
        case 'c':
            return 2.0;
        case 'D':
        case 'd':
            return 1.0;
        case 'F':
        case 'f':
            return 0.0;
        default:
            return -1.0;
    }
}

bool isValidGrade(const string& grade)
{
    return grade == "A" || grade == "a" ||
           grade == "B" || grade == "b" ||
           grade == "C" || grade == "c" ||
           grade == "D" || grade == "d" ||
           grade == "F" || grade == "f";
}

bool isValidRollNumber(const string& rollStr, int& rollNumber)
{
    try
    {
        rollNumber = stoi(rollStr);
        return rollNumber > 0;
    }
    catch (...)
    {
        return false;
    }
}

string getFileName() {
    string fileName;
    cout << "Enter the file name: ";
    getline(cin, fileName);
    return "D:/projectcp/" + fileName + ".txt";
}

void enterstudentdata()
{
    string fileName = getFileName();
    ofstream in(fileName, ios::app);
    if (!in.is_open())
    {
        cout << "File not opened";
        return;
    }

    string name, rollStr, course, grade;
    int rollno;

    cout << "Enter Name Of Student: ";
    getline(cin, name);
    if (name.empty())
    {
        cout << "Invalid input: Name cannot be empty." << endl;
        return;
    }

    cout << "Enter Roll No Of Student: ";
    getline(cin, rollStr);
    if (!isValidRollNumber(rollStr, rollno))
    {
        cout << "Invalid input: Roll number must be a positive integer." << endl;
        return;
    }

    // Store basic information
    in << name << "\n";
    in << rollno << "\n";

    // Enter courses and grades
    for (int i = 0; i < 5; ++i)
    {
        cout << "Enter Course " << (i + 1) << " Of Student: ";
        getline(cin, course);
        if (course.empty())
        {
            cout << "Invalid input: Course cannot be empty." << endl;
            return;
        }

        cout << "Enter Grade for " << course << ": ";
        getline(cin, grade);
        if (!isValidGrade(grade))
        {
            cout << "Invalid input: Grade must be one of A, B, C, D, or F." << endl;
            return;
        }

        in << course << "\n";
        in << grade << "\n";
    }

    in.close();
}

void showstudentdata(bool toFile = false)
{
    string fileName = getFileName();
    ifstream in(fileName, ios::in);
    if (!in.is_open())
    {
        cout << "Error Opening File \n";
        return;
    }

    string outputFileName;
    ofstream outFile;

    if (toFile)
    {
        cout << "Enter the output file name for the report: ";
        getline(cin, outputFileName);
        outFile.open(outputFileName);
        if (!outFile.is_open())
        {
            cout << "Error Opening Output File \n";
            return;
        }
    }

    string name, course, grade;
    int rollno;

    while (getline(in, name))
    {
        in >> rollno;
        in.ignore(); // To ignore the newline character after roll number
        if (toFile)
        {
            outFile << "Name: " << name << endl;
            outFile << "Roll No: " << rollno << endl;
        }
        else
        {
            cout << "Name: " << name << endl;
            cout << "Roll No: " << rollno << endl;
        }

        for (int i = 0; i < 5; ++i)
        {
            getline(in, course);
            getline(in, grade);
            if (toFile)
            {
                outFile << "Course " << (i + 1) << ": " << course << ", Grade: " << grade << endl;
            }
            else
            {
                cout << "Course " << (i + 1) << ": " << course << ", Grade: " << grade << endl;
            }
        }

        if (toFile)
        {
            outFile << "--------------------------" << endl;
        }
        else
        {
            cout << "--------------------------" << endl;
        }
    }

    in.close();
    if (toFile) outFile.close();
}

void showStudentDataByRollNo(bool toFile = false)
{
    string fileName = getFileName();
    ifstream in(fileName, ios::in);
    if (!in.is_open())
    {
        cout << "Error Opening File \n";
        return;
    }

    int targetRollNo;
    cout << "Enter the roll number of the student to display: ";
    cin >> targetRollNo;
    cin.ignore(); // To ignore the newline character left by cin

    string outputFileName;
    ofstream outFile;

    if (toFile)
    {
        cout << "Enter the output file name for the report: ";
        getline(cin, outputFileName);
        outFile.open(outputFileName);
        if (!outFile.is_open())
        {
            cout << "Error Opening Output File \n";
            return;
        }
    }

    string name, course, grade;
    int rollno;

    bool studentFound = false;

    while (getline(in, name))
    {
        in >> rollno;
        in.ignore(); // To ignore the newline character after roll number

        if (rollno == targetRollNo)
        {
            studentFound = true;
            if (toFile)
            {
                outFile << "Name: " << name << endl;
                outFile << "Roll No: " << rollno << endl;
            }
            else
            {
                cout << "Name: " << name << endl;
                cout << "Roll No: " << rollno << endl;
            }

            for (int i = 0; i < 5; ++i)
            {
                getline(in, course);
                getline(in, grade);
                if (toFile)
                {
                    outFile << "Course " << (i + 1) << ": " << course << ", Grade: " << grade << endl;
                }
                else
                {
                    cout << "Course " << (i + 1) << ": " << course << ", Grade: " << grade << endl;
                }
            }

            if (toFile)
            {
                outFile << "--------------------------" << endl;
            }
            else
            {
                cout << "--------------------------" << endl;
            }
            break;
        }
        else
        {
            for (int i = 0; i < 5; ++i)
            {
                getline(in, course);
                getline(in, grade);
            }
        }
    }

    if (!studentFound)
    {
        if (toFile)
        {
            outFile << "Student with roll number " << targetRollNo << " not found." << endl;
        }
        else
        {
            cout << "Student with roll number " << targetRollNo << " not found." << endl;
        }
    }

    in.close();
    if (toFile) outFile.close();
}

void UpdateStudentData()
{
    string fileName = getFileName();
    string newName, newCourse, newGrade, rollStr;
    int oldRollNo, newRollNo;

    // Prompt user for the roll number to be updated
    cout << "Enter the Roll no of the student you want to update: ";
    getline(cin, rollStr);
    if (!isValidRollNumber(rollStr, oldRollNo))
    {
        cout << "Invalid input: Roll number must be a positive integer." << endl;
        return;
    }

    // Prompt user for new data
    cout << "Enter the new name of the student: ";
    getline(cin, newName);
    if (newName.empty())
    {
        cout << "Invalid input: Name cannot be empty." << endl;
        return;
    }

    cout << "Enter the new roll number of the student: ";
    getline(cin, rollStr);
    if (!isValidRollNumber(rollStr, newRollNo))
    {
        cout << "Invalid input: Roll number must be a positive integer." << endl;
        return;
    }

    string newCourses[5], newGrades[5];
    for (int i = 0; i < 5; ++i)
    {
        cout << "Enter the new course " << (i + 1) << " of the student: ";
        getline(cin, newCourses[i]);
        if (newCourses[i].empty())
        {
            cout << "Invalid input: Course cannot be empty." << endl;
            return;
        }

        cout << "Enter the new grade for " << newCourses[i] << ": ";
        getline(cin, newGrades[i]);
        if (!isValidGrade(newGrades[i]))
        {
            cout << "Invalid input: Grade must be one of A, B, C, D, or F." << endl;
            return;
        }
    }

    ifstream inFile(fileName, ios::in);
    string tempFile = fileName + ".tmp";
    ofstream outFile(tempFile, ios::out);

    if (!inFile.is_open() || !outFile.is_open())
    {
        cout << "Error opening file(s) \n";
        return;
    }

    string name, course, grade;
    int rollno;
    bool studentFound = false;

    while (getline(inFile, name))
    {
        inFile >> rollno;
        inFile.ignore(); // To ignore the newline character after roll number

        if (rollno == oldRollNo)
        {
            studentFound = true;
            outFile << newName << endl;
            outFile << newRollNo << endl;

            for (int i = 0; i < 5; ++i)
            {
                outFile << newCourses[i] << endl;
                outFile << newGrades[i] << endl;
            }

            for (int i = 0; i < 5; ++i)
            {
                getline(inFile, course);
                getline(inFile, grade);
            }
        }
        else
        {
            outFile << name << endl;
            outFile << rollno << endl;

            for (int i = 0; i < 5; ++i)
            {
                getline(inFile, course);
                getline(inFile, grade);
                outFile << course << endl;
                outFile << grade << endl;
            }
        }
    }

    inFile.close();
    outFile.close();

    if (!studentFound)
    {
        cout << "Student with roll number " << oldRollNo << " not found." << endl;
        remove(tempFile.c_str()); // Remove temporary file
        return;
    }

    // Replace original file with updated file
    remove(fileName.c_str());
    rename(tempFile.c_str(), fileName.c_str());

    cout << "Student info updated successfully.\n";
}

void CalculateCGPA()
{
    string fileName = getFileName();
    ifstream in(fileName, ios::in);
    if (!in.is_open())
    {
        cout << "Error Opening File \n";
        return;
    }

    string name, course, grade;
    int rollno;

    cout << "Enter the roll number of the student to calculate CGPA: ";
    int targetRollNo;
    cin >> targetRollNo;
    cin.ignore(); // To ignore the newline character left by cin

    bool studentFound = false;

    while (getline(in, name))
    {
        in >> rollno;
        in.ignore(); // To ignore the newline character after roll number

        if (rollno == targetRollNo)
        {
            studentFound = true;
            float totalPoints = 0.0;
            int totalCourses = 0;

            for (int i = 0; i < 5; ++i)
            {
                getline(in, course);
                getline(in, grade);

                float points = convertGradeToPoints(grade);
                if (points == -1.0)
                {
                    cout << "Invalid grade encountered for course " << course << ". Calculation aborted." << endl;
                    return;
                }
                totalPoints += points;
                totalCourses++;
            }

            float cgpa = totalPoints / totalCourses;
            cout << "CGPA of student with roll number " << rollno << " is: " << cgpa << endl;

            break;
        }
        else
        {
            for (int i = 0; i < 5; ++i)
            {
                getline(in, course);
                getline(in, grade);
            }
        }
    }

    if (!studentFound)
    {
        cout << "Student with roll number " << targetRollNo << " not found." << endl;
    }

    in.close();
}

void generateClassSummaryReport(bool toFile = false)
{
    string fileName = getFileName();
    ifstream in(fileName, ios::in);
    if (!in.is_open())
    {
        cout << "Error Opening File \n";
        return;
    }

    string outputFileName;
    ofstream outFile;

    if (toFile)
    {
        cout << "Enter the output file name for the report: ";
        getline(cin, outputFileName);
        outFile.open(outputFileName);
        if (!outFile.is_open())
        {
            cout << "Error Opening Output File \n";
            return;
        }
    }

    string name, course, grade;
    int rollno;

    float totalCGPA = 0.0;
    float highestCGPA = numeric_limits<float>::min();
    float lowestCGPA = numeric_limits<float>::max();
    int studentCount = 0;

    while (getline(in, name))
    {
        in >> rollno;
        in.ignore(); // To ignore the newline character after roll number

        float totalPoints = 0.0;
        int totalCourses = 0;

        for (int i = 0; i < 5; ++i)
        {
            getline(in, course);
            getline(in, grade);

            float points = convertGradeToPoints(grade);
            if (points == -1.0)
            {
                cout << "Invalid grade encountered for course " << course << ". Skipping this student." << endl;
                for (int j = i + 1; j < 5; ++j)
                {
                    getline(in, course);
                    getline(in, grade);
                }
                continue;
            }
            totalPoints += points;
            totalCourses++;
        }

        if (totalCourses == 5)
        {
            float cgpa = totalPoints / totalCourses;
            totalCGPA += cgpa;
            if (cgpa > highestCGPA)
                highestCGPA = cgpa;
            if (cgpa < lowestCGPA)
                lowestCGPA = cgpa;
            studentCount++;
        }
    }

    if (studentCount == 0)
    {
        cout << "No valid student records found." << endl;
        if (toFile) outFile << "No valid student records found." << endl;
    }
    else
    {
        float averageCGPA = totalCGPA / studentCount;
        cout << "Class Summary Report:" << endl;
        cout << "Average CGPA: " << averageCGPA << endl;
        cout << "Highest CGPA: " << highestCGPA << endl;
        cout << "Lowest CGPA: " << lowestCGPA << endl;

        if (toFile)
        {
            outFile << "Class Summary Report:" << endl;
            outFile << "Average CGPA: " << averageCGPA << endl;
            outFile << "Highest CGPA: " << highestCGPA << endl;
            outFile << "Lowest CGPA: " << lowestCGPA << endl;
        }
    }

    in.close();
    if (toFile) outFile.close();
}

void exportReportsToFile()
{
    int reportChoice;
    cout << "Choose the report to export:\n";
    cout << "1. All Students Data\n";
    cout << "2. Student Data by Roll No\n";
    cout << "3. Class Summary Report\n";
    cout << "Enter your choice: ";
    cin >> reportChoice;
    cin.ignore(); // To ignore the newline character left by cin

    switch (reportChoice)
    {
    case 1:
        showstudentdata(true);
        break;
    case 2:
        showStudentDataByRollNo(true);
        break;
    case 3:
        generateClassSummaryReport(true);
        break;
    default:
        cout << "Invalid choice. Please try again.\n";
        break;
    }
}

int main()
{
    int option;
    do
    {
        cout << "\nMain Menu:\n";
        cout << "1. Enter Student Data\n";
        cout << "2. Show All Students Data\n";
        cout << "3. Show Student Data by Roll No\n";
        cout << "4. Update Student Data\n";
        cout << "5. Calculate CGPA\n";
        cout << "6. Generate Class Summary Report\n";
        cout << "7. Export Reports to File\n";
        cout << "8. Exit\n";
        cout << "Enter your choice: ";
        cin >> option;
        cin.ignore(); // To ignore the newline character left by cin

        switch (option)
        {
        case 1:
            enterstudentdata();
            break;
        case 2:
            showstudentdata();
            break;
        case 3:
            showStudentDataByRollNo();
            break;
        case 4:
            UpdateStudentData();
            break;
        case 5:
            CalculateCGPA();
            break;
        case 6:
            generateClassSummaryReport();
            break;
        case 7:
            exportReportsToFile();
            break;
        case 8:
            cout << "Exiting the program.\n";
            break;
        default:
            cout << "Invalid option. Please try again.\n";
        }
    } while (option != 8);

    return 0;
}
